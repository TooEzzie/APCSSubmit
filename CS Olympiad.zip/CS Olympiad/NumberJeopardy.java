import java.util.*;

public class NumberJeopardy 
{
    public static void main(String[] args) 
    {
        System.out.println("Input your input");
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();
        System.out.println(input);
    }
}