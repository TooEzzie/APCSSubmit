import java.util.*;

public class easymode
{
    public static void main(String[] args)
    {
        System.out.println("input ur stuff");
        Scanner dingus = new Scanner(System.in);
        int cases = Integer.parseInt(dingus.nextLine());
        int max = -999999;
        int temp = 0;
        for(int i = 1; i <= cases; i++)
        {
            Scanner run = new Scanner(dingus.nextLine());
            int runners = run.nextInt();
            for(int j = 0; j < runners; j++)
            {
                temp = run.nextInt();
                if(temp > max)
                {
                    max = temp;
                }
            }
            System.out.println("Case " + i + ": " + max);
            max = -9999999;
            temp = 0;
        }
    }
}