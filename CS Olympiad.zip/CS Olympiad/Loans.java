import java.util.*;
import java.io.*;


public class Loans
{
    public static void main(String[] args) 
    {
        System.out.println("Input in the format of duration, down payment, amount of loan, and the number of depreciations");
        Scanner console = new Scanner(System.in);
        String input = console.nextLine();
        String[] input1 = input.split(" ");
        double duration = Double.parseDouble(input1[0]);
        double down = Double.parseDouble(input1[1]);
        double amount = Double.parseDouble(input1[2]);
        int count = Integer.parseInt(input1[3]);
        double car = down+amount;
        int count2 = 0;
        double depreciation = 0;
        System.out.println("Input in the format of Depreciation index, percentage");
        String[] input2 = new String[count];
        
        for(int i = 0; i < count; i++)
        {
            input2[i] = console.nextLine();
        }
        for(int j = 0; j < duration; j++)
        {
            Scanner holder = new Scanner(input2[count2]);
            if(j == holder.nextInt())
            {
                depreciation = holder.nextDouble();
                System.out.println("Dep = " + depreciation);
                if(count2 < count-1)
                {
                    count2++;
                }
            }
            car = car*(1.0 - depreciation);
            if(j > 0)
            {
                amount = amount-down;
            }
            if(car > amount)
            {
                System.out.print(j + " month");
                if(j != 1)
                {
                    System.out.print("s");
                }
                System.out.println(" ");
                break;
            }
            System.out.println(car + " " + amount);
        }
        
    }
}