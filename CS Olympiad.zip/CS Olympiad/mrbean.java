import java.util.*;

public class mrbean
{
    public static void main(String[] args) 
    {
        System.out.println("TYPE INPUt");
        Scanner console = new Scanner(System.in);
        int num = Integer.parseInt(console.nextLine());
        for(int i = 0; i < num; i++)
        {
            System.out.println("Input dimensions");
            Scanner input = new Scanner(console.nextLine());
            int L = input.nextInt();
            int W = input.nextInt();
            int H = input.nextInt();
            if(L > 20 || W > 20 || H > 20)
            {
                System.out.println("Case " + (i+1) + ": bad");
            }
            else
            {
                System.out.println("Case " + (i+1) + ": good");
            }
        }
    }
}