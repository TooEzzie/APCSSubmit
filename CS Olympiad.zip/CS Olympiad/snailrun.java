import java.io.*;
import java.util.*;

public class snailrun
{
    public static void main(String[] args) throws FileNotFoundException
    {
        File file = new File("./input.txt");
        Scanner dingus = new Scanner(file);
        int[] input = new int[4];
        do
        {
            Scanner scan = new Scanner(dingus.nextLine());
            for(int i = 0; i < 4; i++)
            {
                input[i] = scan.nextInt();
            }
            double height = 0;
            int day = 0;
            double fat = input[1]*((double)input[3]/100);
            do
            {
                height += input[1]-(day*fat);
                if(height <= input[0])
                {
                    height -= input[2];
                }
                day++;
            }while(height > 0 && height < input[0]);
            if(height <= 0)
            {
                System.out.println("fail day " + day);
            }
            else
            {
                System.out.println("Success day " + day);
            }
        }while(dingus.hasNextLine() && input[0] != 0);
    }
}