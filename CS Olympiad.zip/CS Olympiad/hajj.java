import java.util.*;

public class hajj
{
    public static void main(String[] args) 
    {
        System.out.println("Input");
        Scanner dingus = new Scanner(System.in);
        String output = "";
        String dingle;
        int i = 1;
        do
        {
            dingle = dingus.nextLine();
            if(dingle.equals("Hajj"))
            {
                output += "Case " + i + ": Hajj-e-Akbar /n";
            }
            else if(dingle.equals("Umrah"))
            {
                output += "Case " + i + ": Hajj-e-Asghar /n";
            }
            else
            {
                break;
            }
            i++;
        }
        while(dingle != "*");
        System.out.println(output);
    }
}