import java.util.*;

public class holes
{
    public static void main(String[] args)
    {
        System.out.println("Input the things");
        Scanner dingus = new Scanner(System.in);
        int numRuns = Integer.parseInt(dingus.nextLine());
        dingus.nextLine();
        int numCol = Integer.parseInt(dingus.nextLine());
        Scanner input = new Scanner(dingus.nextLine());
        int first = input.nextInt();
        int second = input.nextInt();
        int difference = Math.abs(first - second);
        boolean test = true;
        for(int i = 1; i < numCol; i++)
        {
            input = new Scanner(dingus.nextLine());
            first = input.nextInt();
            second = input.nextInt();
            if(Math.abs(first - second) != difference)
            {
                test = false;
            }
        }
        System.out.println(test);
    }
}
