import java.util.*;

public class stupidBrother
{
    public static void main(String[] args) 
    {
        System.out.println("Input the # of numbers: ");
        Scanner console = new Scanner(System.in);
        int count = console.nextInt();
        System.out.println("Input your numbers! Press enter after each number.");
        String[] input = new String[count];
        for(int i = 0; i < count; i++)
        {
            input[i] = console.next();
        }
        System.out.println("OUTPUT");
        for(int i = 0; i < count; i++)
        {
            if(input[i].length() == 5)
            {
                System.out.println("3");
            }
            else if((input[i].charAt(0) == 'o' && input[i].charAt(1) == 'n') || 
            (input[i].charAt(0) == 'o' && input[i].charAt(2) == 'e') || 
            (input[i].charAt(1) == 'n' && input[i].charAt(2) == 'e'))
            {
                System.out.println("1");
            }
            else
            {
                System.out.println("2");
            
            }   
        }
    }
}