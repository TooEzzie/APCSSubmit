import java.util.*;

public class Donations
{
    public static void main(String[] args)
    {
        System.out.println("Input");
        Scanner dingus = new Scanner(System.in);
        Scanner splitter;
        int Commands = dingus.nextInt();
        dingus.nextLine();
        String output = "\nTotal \n";
        int amount = 0;
        int i = 0;
        while (i < Commands)
        {
            String input = dingus.nextLine();
            splitter = new Scanner(input);
            String s = splitter.next();
            if (s.equals("donate"))
            {
                int temp = Integer.parseInt(splitter.next());
                amount += temp;
            }
            else if (s.equals("report"))
            {
                output += Integer.toString(amount) + "\n";
            }
            else
            {
                System.out.println("Wrong");
                i--;
            }
            
            i++;
        } 
        
        System.out.println(output);
    }
}
