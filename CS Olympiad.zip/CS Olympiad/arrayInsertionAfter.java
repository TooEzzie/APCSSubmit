import java.util.*;

public class arrayInsertionAfter
{
    public static void main(String[] args)
    {
        System.out.println("Input your number and the index");
        Scanner dingus = new Scanner(System.in);
        Scanner inputs = new Scanner(dingus.nextLine());
        int[] temp = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] array = new int[temp.length+1];
        int number = inputs.nextInt();
        int index = inputs.nextInt() + 1;
        for(int i = 0; i < array.length; i++)
        {
            if(i < index)
            {
                array[i] = temp[i];
            }
            else if(i == index - 1)
            {
                array[i] = number;
            }
            else
            {
                array[i] = temp[i-1];
            }
        }
        System.out.println(Arrays.toString(array));
    }
}